package fr.villecresnes.etoile.service;

public class BackendService {

	//Ajouter des fonctions qui seront appelées dans le controller
}
